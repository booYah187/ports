Neo-Gensokyo
https://firecat1311.itch.io/neo-gens0
All game files are included. 

Slash and dash through robotic enemies, dodge through danmaku in bullet-time, rack up combos to increase your Power level, pinpoint a boss's openings and dance through their moves to counterattack with perfect timing.

Notes: Special thanks to fiore_firelily@discord at https://firecat1311.itch.io/ for allowing us to distribute the game files.

Controls: 
dpad/l-stick = movement
A/R1 = Dash
B = Attack
X = dash attack 
Y = Stats
start = pause

ported by mattyj513